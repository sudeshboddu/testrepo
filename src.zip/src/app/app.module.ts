import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import { MatTableModule } from '@angular/material';
import { AppComponent } from './app.component';
import { DataComponent } from './data/data.component';
import { TableAppComponent } from './table-app/table-app.component';
import { DhtmlxComboComponent } from './dhtmlx-combo/dhtmlx-combo.component';
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
  { path: 'ID', component: DhtmlxComboComponent },
  {
  path: 'discount',
  component: DhtmlxComboComponent,
  data: { title: 'List' }
  }
];

@NgModule({
  declarations: [
    AppComponent,
    DataComponent,
    TableAppComponent,
    DhtmlxComboComponent
  ],
  imports: [
BrowserModule,
RouterModule.forRoot([])
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
