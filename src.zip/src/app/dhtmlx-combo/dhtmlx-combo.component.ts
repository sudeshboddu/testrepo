import { Component, OnInit, AfterContentInit, Output, EventEmitter } from '@angular/core';
import { comboData } from '../../data';
import { Observable, Subject } from 'rxjs';
import { AdventureTimeService } from '../adventure-time.service';

declare var dhtmlXCombo: any;

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})

export class DhtmlxComboComponent implements OnInit, AfterContentInit {
  myCombo : any;
  public seletedRowList = []; // array to store selected values

  public onCheck = true;
 
public static refreshComboboxData: Subject<any> = new Subject(); 
  constructor(private atService: AdventureTimeService ) {
    DhtmlxComboComponent.refreshComboboxData.subscribe((data)=>{
      debugger;
      this.testRefreshMethod(data);
     // this.myCombo.unCheckAll(data); debugger
   //  this.unSelectOption();
    //  comboData.uncheck(data);

    });
   }

  columns: string[];
  @Output()
  selectedRow:any =  new EventEmitter(); //selected values are emitted
  checkedList:any =  new EventEmitter(); //selected values are emitted

  ngOnInit() {
    
  }

  ngAfterContentInit() {
      this.myCombo = new dhtmlXCombo("combo_zone", "combo", 230, "checkbox",);
      this.myCombo.load(comboData);
      
      this.myCombo.enableFilteringMode(true);
      this.myCombo.attachEvent("onChange", function(value, text){
        this.onCheck = false;
				console.log("onChange event, value: "+value+", text: "+text);
			});
      this.myCombo.attachEvent("onSelectionChange", function(){
        this.onCheck = false;
        console.log("onSelectionChange event");
          console.log("onCheck",this.onCheck)

      });

     this.myCombo.setPlaceholder("Search(Auto Complete)");

     this.setDefaultvalue();
      
  }

 
  testRefreshMethod(data){
    console.log(data);
  }
  addDiscount(){ // to get the selected values from combo
    var selection = this.myCombo.getChecked();
    //allow to capture selected data
    this.seletedRowList = selection;
    this.selectedRow.emit(selection);

    //Reload the combo data
   // this.myCombo.load(comboData);
   var test = this.myCombo.load(comboData);
   console.log("test",test)
       }

  onRowSelected(){
    this.selectedRow.emit(this.seletedRowList); 
  }

  setDefaultvalue(){
    this.seletedRowList.push( "BR-5678(US-Teaming Plus)");
    this.selectedRow.emit(this.seletedRowList); 
  }


  
  onRemoveAll(){ // empty the selectedRow array or to remove all the selected data form the selectedRow array
    this.selectedRow.emit([]);
  }

 
}
