import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { DhtmlxGridComponent } from './dhtmlx-grid/dhtmlx-grid.component';
import { DhtmlxComboComponent } from './dhtmlx-combo/dhtmlx-combo.component';


@NgModule({
  declarations: [
    AppComponent,
    DhtmlxGridComponent,
    DhtmlxComboComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
