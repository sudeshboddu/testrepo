import { Component, OnInit, AfterContentInit, Input, Output } from '@angular/core';
import { Http } from '@angular/http';
import { ReadDataService } from '../read-data.service';
import { EventEmitter } from 'events';

declare var dhtmlXGridObject: any;

@Component({
  selector: 'app-dhtmlx-grid',
  templateUrl: './dhtmlx-grid.component.html',
  styleUrls: [
    '../../assets/ext/dhtmlxGrid/codebase/dhtmlxgrid.css',
    '../../assets/ext/dhtmlxToolbar/codebase/skins/dhtmlxtoolbar_dhx_skyblue.css'
  ]
})
export class DhtmlxGridComponent implements OnInit, AfterContentInit {
  private theGrid: any;
  private numRows: number;
  private numColumns: number;
  private numTables: number;
  private rowsPerPage: number;
  private data: any[];
  private colDef: any[];
  private colWidth: any[];
  private colAlign: any[];
  private colTypes: any[];
  private colNames: any[];
  private eXcell_details: any;
  private showStyle = true;

  @Input() gridBoxId: string;
  @Input() toolBarId: string;
  @Input() headerLabels: string;
  @Input() columnTypes: string;
  @Input() columnWidths: string;
  @Input() columnAlignments: string;
  @Input() columnSort: string;

  @Output() xleEvent: EventEmitter = new EventEmitter();
  @Output() xlsEvent: EventEmitter = new EventEmitter();

  constructor() {
        this.numRows = 20;
        this.numTables = 1;
        this.rowsPerPage = 20;
        this.colNames = [
            'NAME,CEC ID,CITY'
        ];
        this.data = [];
        this.colDef = [];
        this.colWidth = ['100,200,*'];
        this.colAlign = [];
        this.colTypes = [];
        this.numColumns = this.colNames.length;
        this.createColumnDef();
        this.createData();
        // this.eXcell_details = new eXcell_details();
        console.log('Constructor done');
  }

  ngOnInit() {
  }


  ngAfterContentInit() {
    console.log('Init : Init with GridBox Id : ' + this.gridBoxId + ' -- ' + this.headerLabels);
    const theGrid = new dhtmlXGridObject(this.gridBoxId);

    const zdata = [
      ['BR-5678(US-Teaming Plus)'],
      ['BA-ACC1(Accelerator-1)'],
      ['BA-ACC2(Accelerator-2)'],
      ['BR-1234(US-OIP)'],
      ['BR-2345(US-TIP)'],
      ['BR-3468(US-SIP)'],
      ['BR-7890(US-Teaming)'],
      ['CD-Moto-114436(US Motorola)'],
      ['CD-Anom-115799(Anomli STI US)'],
      ['CD-Hone-75930(Honeywell Contract)'],
      ['PP-CMSP-39547(CMSP Simplified pricing)'],
      ['PP-Disti-113773(Disti Security Software)'],
      ['PP-HCA1-39528(HCS Pricing)'],
      ['PP-USH0-41511(US Hospitality Growth)'],
      ['Trade Ins(Trade Ins)']
    ];

    theGrid.setImagePath('../../assets/ext/dhtmlxGrid/codebase/imgs/');
    theGrid.setHeader(this.headerLabels);
    theGrid.setInitWidths(this.columnWidths);
    theGrid.setColAlign(this.columnAlignments);
    theGrid.setColTypes(this.columnTypes);
    theGrid.setColSorting(this.columnSort);
    theGrid.setSkin('dhx_skyblue');
  //  theGrid.enablePaging(true, 10, 5, this.toolBarId);
    theGrid.setPagingSkin('toolbar', 'dhx_skyblue');

    theGrid.setColumnHidden(7, true);

    theGrid.attachEvent('onXLE', this.xleEvent.emit(null));
    theGrid.attachEvent('onXLS', this.xlsEvent.emit(null));

    theGrid.init();

    // theGrid.parse(this.dataService.getData());
    theGrid.parse(zdata, 'jsarray');
    //
    // theGrid.parse(`../../assets/xml/data.xml`);
    this.xleEvent.emit(null);

  }

  onXleEvent(e) {
    console.log('Called');
  }

  onXlsEvent(e) {
    console.log('Called');
  }

  getStyle() {
    if (this.showStyle) {
        return 'yellow';
    } else {
        return '';
    }
  }

  private createData() {
    for (let j = 0; j < this.numRows; j++) {
        const time = new Date(new Date().getTime() + (j * (24 * 60 * 60 * 1000)));
        const valObj: any[] = [];
        for (let i = 0; i < this.numColumns; i++) {
            const val = Math.floor(Math.random() * (7710000 - 1710000) + 1710000) + ',A,B,C';
            valObj.push(`${val}`);
        }
       // console.log(valObj);
        this.data.push(valObj);
    }
  }

  private createColumnDef() {
      for (let i = 0; i < this.colNames.length; i++) {
          this.colDef.push('int');
          this.colWidth.push(100);
          this.colAlign.push('left');
          this.colTypes.push('edn');
      }
      this.colTypes[this.colTypes.length - 1] = 'details';
  }


}
