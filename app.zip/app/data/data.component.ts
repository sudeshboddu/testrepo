import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})

export class DataComponent implements OnInit {

  listTable= []; //storing emitting value
  constructor() { }

  ngOnInit() {
  }

  slectedRow(selectedRow){ //capturing the emitted selectedRow value.
    this.listTable = selectedRow;
  }

  deleteOnImageClick(item){ // table a copying from table b, deleting value from selectedRow
    let index = this.listTable.indexOf(item);
    if(index> -1){
      this.listTable.splice(index, 1);
    }
  }

  // private fieldArray: Array<any> = [];
  // private newAttribute: any = {};
  // deleteFieldValue(index) { //need to test this
  //   console.log("deleteFieldValue");
  //   this.fieldArray.splice(index, 1);
  // }
}
