import { Component, OnInit, AfterContentInit, Output, EventEmitter } from '@angular/core';
import { comboData } from '../../data';
import { Observable, Subject } from 'rxjs';
import { AdventureTimeService } from '../adventure-time.service';

declare var dhtmlXCombo: any;
//declare var dhtmlXComboFromSelect: any;

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})

export class DhtmlxComboComponent implements OnInit, AfterContentInit {
  myCombo : any;
  seletedRowList = []; // array to store selected values
  private onCheck = false;


  constructor(private atService: AdventureTimeService ) { }
  //characters;
  columns: string[];
  @Output()
  selectedRow:any =  new EventEmitter(); //selected values are emitted

  ngOnInit() {
    
  }

  ngAfterContentInit() {
      this.myCombo = new dhtmlXCombo("combo_zone", "combo", 230, "checkbox",);
      this.myCombo.load(comboData);

      this.myCombo.enableFilteringMode(true);
      this.myCombo.attachEvent("onChange", function(value, text){
				console.log("onChange event, value: "+value+", text: "+text);
			});
      this.myCombo.attachEvent("onSelectionChange", function(){
        // console.log("onSelectionChange event");
        //  console.log("onCheck",this.onCheck)
      });

     this.myCombo.setPlaceholder("Search(Auto Complete)");
      
  }

  addDiscount(){ // to get the selected values from combo

    var selection = this.myCombo.getChecked();
    //allow to capture selected data
    this.seletedRowList = selection;
    this.selectedRow.emit(selection);

    //Reload the combo data
    this.myCombo.load(comboData);

    
 
  }
  onRowSelected(){
    this.selectedRow.emit(this.seletedRowList);
  }

  
  onRemoveAll(){ // empty the selectedRow array or to remove all the selected data form the selectedRow array
    //this.seletedRowList = [];
    this.selectedRow.emit([]);
  }

 
}
