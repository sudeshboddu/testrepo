export const environment = {
  production: false,
  getMenuServiceUrl: 'http://localhost:3000/api/menu?local'
};
