icw.modal = {

    disabled      : false,
    animateSpeed  : 500,
    hideDelay     : 1000,

    // Shows a modal dialog
    show : function (args) {
      
        // Don't proceed if modals are disabled.        
        if (icw.modal.disabled || $(args.anchor).attr("modalopen")) 
			    return $(".icwModal[anchorid='" + $(args.anchor).attr("anchorid") + "']");

        // Set defaults and other values from the arguments.
        icw.modal.setArgumentDefaults(args);
                
        // Grab the content for the modal from the corresponding div
        var modalContent = $(args.content).clone(true);

        // Give a new ID to each item with an ID to avoid replicating them
        icw.modal.assignNewIds(modalContent);  
               
        // Build the drop shadowed box around the content
        var modal = icw.modal.buildBox({
            type : "modal",
            content : $(modalContent).outerHtml()
        });
       
        // Display an overlay if requested        
        if (args.screen)
            icw.modal.renderOverlay(modal);
                    
        // Insert the modal code into the page        
        icw.modal.addModalToPage(modal, args);                        

        if (args.callback) {
            // create the list of variables that will be accessible to the callback function
            // The first 2 lines are for backwards-compatibility: if you only want modal, you
            // don't have to reference it as foo.modal; you can reference it as just plain foo
            var callbackArgs    = modal;
            callbackArgs.modal  = modal;
            callbackArgs.anchor = args.anchor;
            eval(args.callback(callbackArgs));            
        }
                        
        // Place the modal
        icw.modal.sizeModal(modal, args);
        var location = icw.modal.positionModal(modal, args);
        icw.modal.setArrowPosition(modal, args, location);
        icw.modal.displayModal(modal, args, location);
        return modal;
    },
    
    // Hides a currently showing modal dialog
    hide : function(args) {

        // For backwards-compatibility -- makes both "modal" and "args.modal" accessible to the callback
        var modal; 
        if (args.modal)
            modal = $(args.modal);
        else
            modal = $(args);                
        
        var anchorid = modal.attr("anchorid");
        var anchor = $("*[anchorid=" + anchorid + "]");
        anchor.removeAttr("modalopen");
        anchor.removeAttr("anchorid");

        // Disable shadows before fading out (only in IE7, controlled via CSS)        
        modal.removeClass("icwShowShadows");
        var wrapper = $("#icwModalWrapper" + modal.attr("uniqueId"));
        var washout = $("#icwModalWashout" + modal.attr("uniqueId"));
        var hideSelect = $("#icwModalHideSelect" + modal.attr("uniqueId"));
        if ($(modal).attr("animate")) {
            // Fade out the modal
            $(modal).fadeOut("normal",
                function(){
                    // Remove the modal
                    wrapper.hide(); wrapper.remove();
                    // Remove the overlay
                    washout.hide(); washout.remove();
                    // Remove the iframe
                    hideSelect.hide(); hideSelect.remove();

                    if ($(modal).attr("screen")) {
                        $(".icwModal").not("[screen]").css("visibility","visible");
                    }
                }
            );
        } else {
            // Remove the modal
            wrapper.hide(); wrapper.remove();
            // Remove the overlay
            washout.hide(); washout.remove();
            // Remove the iframe
            hideSelect.hide(); hideSelect.remove();
        }
        modal = undefined;
    },
    
    
    // Sets default values for arguments that have not been specified
    setArgumentDefaults: function(args) {
		if (!args.anchor)
			throw "An anchor must be specified.";
			
        args.anchor       = args.anchor;
        args.content      = args.content;
        args.mode         = (args.mode         != undefined) ? args.mode         : "modal";
        args.width        = (args.width        != undefined) ? args.width        : "calculate";
        args.height       = (args.height       != undefined) ? args.height       : "calculate";
        args.maxWidth     = (args.maxWidth     != undefined) ? args.maxWidth     : null;
        args.maxHeight    = (args.maxHeight    != undefined) ? args.maxHeight    : null;
        args.align        = (args.align        != undefined) ? args.align        : "auto";
        args.callback     = (args.callback     != undefined) ? args.callback     : null;
        args.fixOverflow  = (args.fixOverflow  != undefined) ? args.fixOverflow  : true;
        args.arrow        = (args.arrow        != undefined) ? args.arrow        : 
                            (args.mode == "modal")           ? false             : true;
        args.arrowPos     = (args.arrowPos     != undefined) ? args.arrowPos     : 
							(args.arrow) ? "bottom" : null;
        args.screen       = (args.screen       != undefined) ? args.screen       :
                            (args.mode == "modal")           ? true              : false;
        args.animate      = (args.animate      != undefined) ? args.animate      : 
                            (args.mode == "modal")           ? true              : false;
        args.animateSpeed = (args.animateSpeed != undefined) ? args.animateSpeed : icw.modal.animateSpeed;        
    },
    
    // Creates an overlay on the screen and displays it.
    renderOverlay : function(modal) {

        // If we're using IE, we need to overlay an iframe to block out ActiveX elements such as <select> tags
        if ($.browser.msie) {
            $("body").append('<iframe class="icwModalHideSelect" id="icwModalHideSelect' + modal.attr("uniqueId") + '" src="javascript:false;document.write(\'\');"></iframe>');
        }
        // Create the 30% opaque white overlay        
        $("body").append('<div class="icwModalWashout" id="icwModalWashout' + modal.attr("uniqueId") + '">&nbsp;</div>');
    
        // Determine the inner dimensions of the browser window
        // Determine the height of the content in the page
        var bodyHeight = $(document).height();
        var bodyWidth =  $(document).width();
        // Stretch the iframe to cover the content of the page
        var hideSelect = $("#icwModalHideSelect" + modal.attr("uniqueId"));
        var washout = $("#icwModalWashout" + modal.attr("uniqueId"));
        if ($.browser.msie) {
            hideSelect.height(bodyHeight);
            hideSelect.width(bodyWidth);
        }
        
        // Stretch the overlay to cover the content of the page
        washout.height(bodyHeight);
        washout.width(bodyWidth);
              
    },
    
    // Give a new ID to each item with an ID to avoid replicating them.
    assignNewIds: function(modalContent) {        
        $(modalContent).find("*[id]").each(function () {
            var id = $(this).attr("id");
            var newId = "icwModal_" + id;
            $(this).attr("id",newId);
        });
    },
    
    addModalToPage: function(modal, args) {
    
        $("body").append(modal);
        $(modal).css("visibility","hidden"); // Otherwise the box flickers in FF        
        $(modal).wrap('<div class="icw" id="icwModalWrapper' + modal.attr("uniqueId") + '">');
        // Enable modal only elements
        $(modal).find(".icwModalOnly").each(function () {
            icw.common.uncomment(this);
        });
        $(modal).addClass("icwPreparingModal");
        $(modal).css("visibility","visible"); // Otherwise the box flickers in FF         
        
        // Now that code is uncommented, attach events
        icw.chrome.initButtons(modal);
        icw.temporary.showDisabledLinkAlerts(modal);
        icw.form.highlightContent();
    },
    
    // Sizes the modal content based on the arguments specified
    sizeModal: function(modal, args) {
      icw.modal.setArgumentDefaults(args);        
      
      var modalContent = $(modal).find(".icwModalContent"); 
      var calculatedWidth = args.width == "calculate";
      var calculatedHeight = args.height == "calculate";
      if (calculatedWidth)  {
        if (!calculatedHeight)
          modalContent.height(args.height); // Apply the height to deal with wrapping                          
        args.width = modalContent[0].offsetWidth;           
        if (args.maxWidth && (args.width > args.maxWidth)) 
			    args.width = args.maxWidth;
      }
        
      if (calculatedHeight) {
        if (!calculatedWidth)
          modalContent.width(args.width); // Apply the width to deal with wrapping
        args.height = modalContent[0].offsetHeight; 
        if (args.maxHeight && (args.height > args.maxHeight))
			    args.height = args.maxHeight;
      }
      var modalDetails = new ModalDetails(modal, args, modalContent);
      if (!calculatedWidth) {			
			  modalContent.width(modalDetails.modalContentWidth);
			  modal.width(modalDetails.modalWidth);
		  }
		  if (!calculatedHeight) {		
			  modalContent.height(modalDetails.modalContentHeight);
			  modal.height(modalDetails.modalHeight);
		  }
      modal.removeClass("icwPreparingModal");       
    },
      
    positionModal : function(modal, args) 
    {  
        icw.modal.setArgumentDefaults(args);
        var modalDetails = new ModalDetails(modal, args);
        var anchorDetails = new AnchorDetails(args);
        
        // Determine the inner dimensions of the browser window        
        var scrollTop  = $(window).scrollTop();
        var scrollLeft = $(window).scrollLeft();
        var winHeight = $(window).height();
        var winWidth  = $(window).width();
        
        var arrowHeight = $(modal).find(".icwModalArrow").height();
        var arrowWidth  = $(modal).find(".icwModalArrow").width();    
                
        // Set the modal's position                    
        var endTop = 0, endLeft = 0, topAdjustedBy = 0, leftAdjustedBy = 0;        
        if (args.mode == "modal") 
        {
            // Center the modal
            endTop  = scrollTop + ((winHeight - modalDetails.modalContentHeight) / 2);
            endLeft = scrollLeft + ((winWidth - modalDetails.modalContentWidth) / 2);
            if (modal.is(".icwScrollable")) 
                endTop = 0;
        }
        else 
        {            
            // first see if a horiz/vert space was set
            if (args.alignLeft || args.alignRight) { var horizSet = true; }
            if (args.alignTop || args.alignBottom) { var vertSet = true;  }
            if ((args.align == "auto") && (!horizSet && !vertSet)) {

                // Auto-detect endLeft
                // If the anchor is in the left half of the screen, horiz-align right;
                // If the anchor is in the right half of the screen, horiz-align left.
                var horizSpace = anchorDetails.anchorWidth + modalDetails.modalWidth;
                var vertSpace  = anchorDetails.anchorHeight + modalDetails.modalHeight;
                if (horizSpace < winWidth) {
                    // there's enough space to do it left-right, so do that
                    if (anchorDetails.anchorLeft <= (winWidth / 2)) {
                        args.align = "right";
                        if (!args.arrowPos) { args.arrowPos = "left"; }
                    } else {
                        args.align = "left";
                        if (!args.arrowPos) { args.arrowPos = "right"; }
                    }
                } else {
                    // we'll put it above or below
                    if ((anchorDetails.anchorTop + (anchorDetails.anchorHeight / 2)) <= (winHeight / 2)) {
                        args.align = "bottom";
                        if (!args.arrowPos) { args.arrowPos = "top"; }
                    } else {
                        args.align = "top";
                        if (!args.arrowPos) { args.arrowPos = "bottom"; }
                    }
                }		
            }
            
            var adjustPaddingLeft   = (args.alignLeft   == undefined) ? true : false;
            var adjustPaddingRight  = (args.alignRight  == undefined) ? true : false;
            var adjustPaddingTop    = (args.alignTop    == undefined) ? true : false;
            var adjustPaddingBottom = (args.alignBottom == undefined) ? true : false;
            if (args.align == "left")   { args.alignRight  = args.alignRight ? args.alignRight : "anchorLeft"; args.arrowPos = "right";  }
            if (args.align == "right")  { args.alignLeft   = args.alignLeft ? args.alignLeft : "anchorRight";	 args.arrowPos = "left";   }
            if (args.align == "top")    { args.alignBottom = args.alignBottom ? args.alignBottom : "anchorTop";    args.arrowPos = "bottom"; }
            if (args.align == "bottom") { args.alignTop    = args.alignTop ? args.alignTop : "anchorBottom"; args.arrowPos = "top";    }
            if (args.align == "center") {
                args.alignTop  = "anchorTop + (anchorHeight / 2) - (modalDetails.modalHeight / 2)";
                args.alignLeft = "anchorLeft + (anchorWidth / 2) - (modalDetails.modalWidth / 2)";
            }
            
            // Refactored the anchor details to a new class, but need to account for passing in old non-prefixed data
            args.alignRight = args.alignRight && args.alignRight.replace(/anchor/g, "anchorDetails.anchor");
            args.alignLeft = args.alignLeft && args.alignLeft.replace(/anchor/g, "anchorDetails.anchor");
            args.alignBottom = args.alignBottom && args.alignBottom.replace(/anchor/g, "anchorDetails.anchor");
            args.alignTop = args.alignTop && args.alignTop.replace(/anchor/g, "anchorDetails.anchor");
            
            if (args.alignLeft) {            
                endLeft  = eval(args.alignLeft);
                //if (adjustPaddingLeft) { endLeft = endLeft - (modalDetails.modalPaddingLeft / 2); }
            }
            if (args.alignRight) {
                endLeft  = eval(args.alignRight) - modalDetails.modalWidth - modalDetails.modalPaddingRight;
                //if (adjustPaddingRight) { endLeft = endLeft - (modalDetails.modalPaddingLeft / 2); }
            }
            if (args.alignTop) {
                endTop = eval(args.alignTop);
                //endTop -= modalDetails.modalPaddingTop / 2;
               //if (adjustPaddingTop) { endTop -= modalDetails.modalPaddingTop / 2; }                
            }
            if (args.alignBottom) {      				                           
                endTop = eval(args.alignBottom) - modalDetails.modalHeight;
                //endTop = endTop + (modalDetails.modalPaddingBottom / 2);
                //if (adjustPaddingBottom) { endTop = endTop + (modalDetails.modalPaddingBottom / 2); }
            }
                
            if (!endTop) {
                // if we're horizontally aligned, now set the vertical
                // Set the specific alignment parameters, if they are set
                // default to center...
                endTop = anchorDetails.anchorTop + (anchorDetails.anchorHeight / 2) - ((modalDetails.modalHeight - modalDetails.modalPaddingTop) / 2) - (arrowHeight / 2);
            }
            if (!endLeft) {
                endLeft = anchorDetails.anchorLeft + (anchorDetails.anchorWidth / 2) - ((modalDetails.modalWidth - modalDetails.modalPaddingLeft) / 2) - (arrowWidth / 2);
            }                         
                        
            if (args.fixOverflow) {
                var minTop       = scrollTop - (modalDetails.modalPaddingTop / 2);
                var maxTop       = winHeight + scrollTop - modalDetails.modalHeight + (modalDetails.modalPaddingBottom / 2);
                var minLeft      = scrollLeft - (modalDetails.modalPaddingLeft / 2);
                var maxLeft      = (winWidth + scrollLeft) - modalDetails.modalWidth + (modalDetails.modalPaddingRight / 2);
                var minArrowTop  = anchorDetails.anchorTop + (anchorDetails.anchorHeight / 2) - (arrowHeight / 2) - (modalDetails.modalPaddingTop / 2);
                var maxArrowTop  = anchorDetails.anchorTop + (anchorDetails.anchorHeight / 2) + (arrowHeight / 2) - modalDetails.modalHeight + modalDetails.modalPaddingBottom;
                // now adjust
                if (!args.alignTop && !args.alignBottom) {
                    if (endTop < minTop) {
                        endTop = (minArrowTop < minTop) ? minArrowTop : minTop;
                    }
                    // Adjust the height of the modal if it's off the bottom edge of the screen
                    else if (endTop >= maxTop) {
                        endTop = (maxArrowTop > maxTop) ? maxArrowTop : maxTop;
                    }
                }
                if (endLeft < minLeft) { 
					leftAdjustedBy = endLeft - minLeft;
                    endLeft = minLeft;                    
                } else if (endLeft > maxLeft) {
					leftAdjustedBy = maxLeft - endLeft;
                    endLeft = maxLeft;
                }
            }
        }
        
        return {endTop: endTop, endLeft: endLeft, topAdjustedBy: topAdjustedBy, leftAdjustedBy: leftAdjustedBy};
    },
    
    setArrowPosition : function(modal, args, location)
    {        
        icw.modal.setArgumentDefaults(args);
        var modalDetails = new ModalDetails(modal, args);
        var anchorDetails = new AnchorDetails(args);
        
        // Set arrow position
        if (args.arrow && args.arrowPos) {
            if (args.arrowPos == "top")    { $(modal).find(".icwModalArrow").addClass("icwModalArrowTop");    }
            if (args.arrowPos == "right")  { $(modal).find(".icwModalArrow").addClass("icwModalArrowRight");  }
            if (args.arrowPos == "bottom") { $(modal).find(".icwModalArrow").addClass("icwModalArrowBottom"); }
            if (args.arrowPos == "left")   { $(modal).find(".icwModalArrow").addClass("icwModalArrowLeft");   }
            
            var arrowHeight = $(modal).find(".icwModalArrow").height();
            var arrowWidth  = $(modal).find(".icwModalArrow").width();            
            
            var arrowTop = 0, arrowLeft = 0;
            if (args.arrowPos == "left" || args.arrowPos == "right")
            {
                arrowTop = modalDetails.modalHeight / 2 - (arrowHeight / 2);
                if (args.arrowPos == "right")                
                    arrowLeft = modalDetails.modalWidth - modalDetails.modalPaddingRight - modalDetails.modalBorderRight;                
            }
            else if (args.arrowPos == "top" || args.arrowPos == "bottom")
            {
				arrowLeft = modalDetails.modalWidth / 2 - arrowWidth/2;
                if (args.arrowPos == "bottom")
                    arrowTop = modalDetails.modalHeight - modalDetails.modalPaddingBottom;                
            }
            $(modal).find(".icwModalArrow").css("top", arrowTop + location.topAdjustedBy);
            $(modal).find(".icwModalArrow").css("left", arrowLeft + location.leftAdjustedBy);
        } 
        else
            $(modal).find(".icwModalArrow").hide();
    },
    
    displayModal : function(modal, args, location)
    {        
        icw.modal.setArgumentDefaults(args);
        var modalDetails = new ModalDetails(modal, args);
        var anchorDetails = new AnchorDetails(args);

        // Enable shadows immediately since this one isn't fading in       
        $(modal).css("width", modalDetails.modalWidth); // Fix for broken bottom shadow in IE7
        if (args.animate) {
            if (args.mode == "modal") {
                var startTop  = anchorDetails.anchorTop;
                var startLeft = anchorDetails.anchorLeft;
                $(modal).find(".icwModalArrow").hide();
                // Position the starting point of the modal
                $(modal).css({top: startTop, left: startLeft, width: 0, height: 0, margin: "auto"});
                $(modal).animate({top: location.endTop, left: location.endLeft, width: modalDetails.modalWidth, height: modalDetails.modalHeight},args.animateSpeed);
                $(modal).find(".icwModalArrow").show();
            } else {
                $(modal).css({top: location.endTop, left: location.endLeft, margin: "auto", display: "none"});
                $(modal).fadeIn("normal");
            }
            $(modal).attr("animate",true);
        } else {
            $(modal).css({top: location.endTop, left: location.endLeft, margin: "auto"});
        }

        $(modal).addClass("icwShowShadows");
        $("#icwModalHideSelect").show();

        var anchor = args.anchor;        
        var anchorid = icw.modal.getRandomID();
        $(modal).attr("anchorid",anchorid);
        $(args.anchor).attr("anchorid",anchorid);

        //if (args.mode == "modal")
			$(args.anchor).attr("modalopen",true);
        if (args.screen) {
            $(modal).attr("screen",true);
            $(".icwModal").not("[screen]").css("visibility","hidden");
        }
    },
    
    getRandomID : function () {        
        return new Date().getTime();
    },    

    buildBox : function(args) {
        
        var modal = $('<div class="icwModal" uniqueId="' + icw.modal.getRandomID() + '"></div>');
        modal.append('<div class="icwModalTop">&nbsp;</div>');
        modal.append('<div class="icwModalLeft"></div>');
        modal.find(".icwModalLeft").append('<div class="icwModalRight"></div>');
        modal.find(".icwModalRight").append('<div class="icwModalContent icwClear">' + args.content + '</div>');
        modal.append('<div class="icwModalBottomLeft"></div>');
        modal.find(".icwModalBottomLeft").append('<div class="icwModalBottomRight"></div>');
        modal.find(".icwModalBottomRight").append('<div class="icwModalBottom">&nbsp;</div>');
        modal.append('<div class="icwModalArrow">&nbsp;</div>');
        
        return $(modal);
    },
    
	getModalDimensions : function(modal) {
		modal = modal[0];
		var display = $(modal).css('display');
		if (display && display != 'none') // Safari bug 
		return { width: modal.offsetWidth, height: modal.offsetHeight };
		// All *Width and *Height properties give 0 on elements with display none,
		// so enable the element temporarily
		var els = modal.style;
		var originalVisibility = els.visibility;
		var originalPosition = els.position;
		var originalDisplay = els.display;
		els.visibility = 'hidden';
		els.position = 'absolute';
		els.display = 'block';
		var originalWidth  = element.clientWidth, originalHeight = element.clientHeight;
		els.display = originalDisplay;
		els.position = originalPosition;
		els.visibility = originalVisibility;
		return { width: originalWidth, height: originalHeight };    
	}    
};

// The preLoadedModalContent parameter is provided to skip the find call 
// if you have already found the modal content. This improves performance on IE6
function ModalDetails(modal, args, preLoadedModalContent) {
	if (args.modalDetails != undefined) // Cache the results
		return args.modalDetails;
		
  var modalContent = preLoadedModalContent ? preLoadedModalContent : $(modal).find(".icwModalContent");
  
  this.modalOffsets = modal.offset({border: true, padding: true});

  // Originally these called modal.height() and modal.width(), but reading
  // offsetHeight/offsetWidth directly seems to be much, much faster. (--APD)
  var dims = icw.modal.getModalDimensions(modal);
  
  this.modalHeight = dims.height;
  this.modalWidth  = dims.width; 
  this.modalContentOffsets = modalContent.offset({border: true, padding: true});
  this.modalContentHeight = args.height;
  this.modalContentWidth  = args.width;   

  this.modalPaddingTop    = this.modalContentOffsets['top'] - this.modalOffsets['top'];
  this.modalPaddingBottom = this.modalHeight - this.modalContentHeight - this.modalPaddingTop;    
  this.modalPaddingLeft   = parseFloat($(modal).find(".icwModalLeft").css("paddingLeft")); 
  this.modalPaddingRight  = parseFloat($(modal).find(".icwModalRight").css("paddingRight")); 
  this.modalBorderLeft    = parseFloat($(modalContent).css("borderLeftWidth"));
  this.modalBorderRight   = parseFloat($(modalContent).css("borderRightWidth"));
  this.modalBorderBottom  = parseFloat($(modalContent).css("borderBottomWidth"));
  this.modalBorderTop     = parseFloat($(modalContent).css("borderTopWidth"));
       
  // FF does not calculate modal.width properly - let's force it
  this.modalWidth = this.modalContentWidth + this.modalPaddingLeft + this.modalPaddingRight;    
  this.modalHeight = this.modalContentHeight + this.modalPaddingTop + this.modalPaddingBottom -
					 this.modalBorderBottom - this.modalBorderTop;


  args.modalDetails = this;
}

function AnchorDetails(args)
{
	if (args.anchorDetails != undefined) // Cache the results
		return args.anchorDetails;
		
    // Get the anchor's position
    this.anchorOffsets = $(args.anchor).offset({border: true, padding: true});
    this.anchorWidth   = $(args.anchor).width();
    this.anchorHeight  = $(args.anchor).height();
    this.anchorTop     = this.anchorOffsets['top'];
    this.anchorLeft    = this.anchorOffsets['left'];
    this.anchorRight   = this.anchorLeft + this.anchorWidth;
    this.anchorBottom  = this.anchorTop  + this.anchorHeight;
    
    args.anchorDetails = this;
}