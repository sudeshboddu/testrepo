import { AppComponent } from './app.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { StackingComponent } from './stacking/stacking.component';
import { FileUploaderComponent } from './file-uploader/file-uploader.component';

const appRoutes: Routes = [
  {
    path: 'newstacking',
    component: StackingComponent
  },
  {
      path:'fileupload',
      component:FileUploaderComponent
  } ,  
  {
    path: '',
    component: StackingComponent
  },
 
  {
    path: '**',
    component: ErrorComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
