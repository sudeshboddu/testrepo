import { Component, OnInit, ElementRef, Input, OnDestroy } from '@angular/core';

import { DcModalService } from './../dc-modal.service';

@Component({
  selector: 'app-dc-modal',
  templateUrl: './dc-modal.component.html',
  styleUrls: ['./dc-modal.component.css']
})
export class DcModalComponent implements OnInit, OnDestroy {

  // Taking the 'id' of the modal component as input.
  @Input() id: string;

  // 'element' will hold the reference to the element injected via constructor.
  private element: any;

  /**
   * Injecting the 'DcModalService' and 'ElementRef'
   */
  constructor(private dcModalService: DcModalService, private elmnt: ElementRef) {
                this.element = elmnt.nativeElement;
  }

  /**
   * Adding the component to the DOM and registering it with the service 
   * for future operations.
   */
  ngOnInit() {
    const modal = this; // assigned for ease of use and readability

    // Ensure that an 'id' is present for the element
    if (!this.id) {
      console.log('Attribute \'id\' is required to create a \'DcModal\' component');
      return;
    }

    // Adding the component to the DOM
    document.body.appendChild(this.element);

    // Registering the modal with the modal service
    this.dcModalService.add(this);
  }

  /**
   * Removing the modal from the service
   */
  ngOnDestroy(): void {
    this.dcModalService.remove(this.id);
    this.element.remove();
  }

  /**
   * Open modal
   */
  open(): void {
    this.element.style.display = 'block';
    // document.body.classList.add('modal-open');
  }

  /**
   * Close modal
   */
  close(): void {
    this.element.style.display = 'none';
    // document.body.classList.remove('modal-open');
  }
}
