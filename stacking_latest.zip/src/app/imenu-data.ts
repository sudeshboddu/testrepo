  export interface IMenuItem {
      url: string;
      label: string;
  }

  export interface ICreate {
      groupTitle: string;
      menuItems?: IMenuItem[];
  }

  export interface IManage {
      groupTitle: string;
      menuItems?: IMenuItem[];
  }

  export interface ISearch {
      groupTitle: string;
      menuItems?: IMenuItem[];
  }

  export interface IReports {
      groupTitle: string;
      menuItems?: IMenuItem[];
  }

  export interface IMenu {
      createMenu: ICreate;
      manageMenu: IManage;
      searchMenu: ISearch;
      reportsMenu: IReports;
  }

  export interface IMenuData {
      menu: IMenu;
      roles: string[];
      loggedInUser: string;
      proxy: boolean;
      proxyUser?: string;
  }
