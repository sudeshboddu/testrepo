import { Component, OnInit, Input } from '@angular/core';
import { FileUploadResponse } from '../pojo/FileUploadResponse';
import { FileUploadBehaviorService } from '../behavior/FileUploadBehavior.service';

@Component({
  selector: 'app-testComponent',
  templateUrl: './testComponent.component.html',
  styleUrls: ['./testComponent.component.css']
})
export class TestComponentComponent implements OnInit {

  data: FileUploadResponse = new FileUploadResponse(1111,'a','b');
  constructor( private fileUploadBehaviorService: FileUploadBehaviorService) { }

  ngOnInit() {
    this.fileUploadBehaviorService.getSubscription().subscribe(responseData => {

      if (responseData == null) {
        console.log('Got a null resposne now.. ');
      } else {
        console.log('The response data got in test component is ' + responseData.batchId + ' ' + responseData.result);
        this.data = responseData;
      }
    });
  }


}
