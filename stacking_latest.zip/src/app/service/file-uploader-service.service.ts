import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { FileUploadResponse } from '../pojo/FileUploadResponse';

// A class member cannot have a const variable. Moving it outside.
const headers = new HttpHeaders().set('Access-Control-Allow-Origin', '*');
headers.set('Content-Type', 'multipart/form-data');

@Injectable()
export class FileUploaderServiceService {
  constructor(private httpClient: HttpClient) {}

  postFile(
    fileToUpload: File,
    actionEvent: string,
    pivotCode: string
  ): Observable<FileUploadResponse> {
    const endpoint = 'http://localhost:3000';
    let resp: FileUploadResponse;
    resp = new FileUploadResponse(1, 'a', 'b');

    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    formData.append('actionEvent', actionEvent);
    formData.append('pivotCode', pivotCode);

    return this.httpClient.post<FileUploadResponse>(endpoint, formData, {
      headers: { 'Access-Control-Allow-Origin': '*' }
    });
  }

  handleError(err: any) {
    console.error('Exception while uploading the file ' + err);
    return 'Error';
  }
}
