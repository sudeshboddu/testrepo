import { DhtmlxComboComponent } from './../dhtmlx-combo/dhtmlx-combo.component';
import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { AddRemoveBehaviorService } from '../behavior/AddRemoveBehavior.service';
import { AddRemove } from '../pojo/AddRemove';
import { CommonModule } from '@angular/common';
import { element } from 'protractor';
@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})

export class DataComponent implements OnInit {
  public listTable: AddRemove[] = []; //storing emitting value
  checkedTable=  [];
  selectedValues = new Map();
  pivotDiscount:AddRemove = null;


  constructor(private addRemoveBehaviorService: AddRemoveBehaviorService, private chRef: ChangeDetectorRef) {
  //  chRef.detectChanges(); //Whenever you need to force update view
   }

  ngOnInit() {
    this.addRemoveBehaviorService.getSubscription().subscribe(responseData2 => {

      if (responseData2 == null) {
        console.log('Got a null resposne now in data list component ');
      } else {

        this.listTable = [];
        if (this.pivotDiscount != null) {
          this.listTable.push(this.pivotDiscount);
        }
        console.log('In the beginning, the listTable size is '+this.listTable.length);
        console.log('The another data got in test component is ' + responseData2 );

        responseData2.forEach(element => {
          console.log('In the data node.. '+ element.discountCode);

          if (element.isPivot) {
            this.pivotDiscount = element;
          }
          this.listTable.push(element);
          this.chRef.detectChanges();
        });
      }

      console.log('In the END, the listTable size is '+this.listTable.length+' '+this.pivotDiscount.discountCode);
    });
  }


  /**
   * Remove element that was clicked with "x" from the list. The same element should be
   * unchecked.
   * @param item
   */
  deleteOnImageClick(item) {

    console.log('The value clicked for x is '+item);
    let pos: number = -1;

    for (var i =0; i < this.listTable.length; i++) {
      if (this.listTable[i].discountCode == item) {
        pos = i;
        console.log('the position value is '+ pos);
                break;
      }
    }


    if(pos > -1){
      this.listTable.splice(pos, 1);
      // we have to subtract 1 as the pivot is the first element in the listbox
      // whereas in the drop down, the pivot wont exist
      this.addRemoveBehaviorService.broadcastRemove(pos - 1);
     // DhtmlxComboComponent.refreshComboboxData.next(item);
    }
  }

}
