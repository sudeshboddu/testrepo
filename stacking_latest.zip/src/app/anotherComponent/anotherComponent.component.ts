import { Component, OnInit } from '@angular/core';
import {FileUploadResponse} from '../pojo/FileUploadResponse';
import {FileUploadBehaviorService} from '../behavior/FileUploadBehavior.service';

@Component({
  selector: 'app-anotherComponent',
  templateUrl: './anotherComponent.component.html',
  styleUrls: ['./anotherComponent.component.css']
})
export class AnotherComponentComponent implements OnInit {

  data2: FileUploadResponse = new FileUploadResponse(2222,'a','b');
  constructor( private fileUploadBehaviorService: FileUploadBehaviorService) { }

  ngOnInit() {
    this.fileUploadBehaviorService.getSubscription().subscribe(responseData2 => {

      if (responseData2 == null) {
        console.log('Got a null resposne now in another component ');
      } else {
        console.log('The another data got in test component is ' + responseData2.batchId + ' ' + responseData2.result);
        this.data2 = responseData2;
      }
    });
  }


}
