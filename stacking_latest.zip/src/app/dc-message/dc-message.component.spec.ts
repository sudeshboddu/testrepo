import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcMessageComponent } from './dc-message.component';

describe('DcMessageComponent', () => {
  let component: DcMessageComponent;
  let fixture: ComponentFixture<DcMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
