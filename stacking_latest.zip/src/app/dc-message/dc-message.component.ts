import { IMessage } from './../interfaces/imessage';
import { DcMessageService } from './../dc-message.service';
import { Component, OnInit } from '@angular/core';
import { EnumMessageType } from '../interfaces/imessage';

@Component({
  selector: 'app-dc-message',
  templateUrl: './dc-message.component.html',
  styleUrls: ['./dc-message.component.css']
})
export class DcMessageComponent implements OnInit {

  errorMessages: IMessage[];
  warningMessages: IMessage[];
  infoMessages: IMessage[];

  /**
   * Constructor
   *
   * @param dcMessageSvc Injecting the DcMessageService
   */
  constructor(private dcMessageSvc: DcMessageService) { }

  /**
   * Handling the 'OnInit' event.
   * Subscribing to 'DcMessageService' and filtering the messages in separate bins (based on their type).
   */
  ngOnInit() {
    // Subscribe to the 'messages' subject
    this.dcMessageSvc.messages.subscribe(currentMessages => {
      console.log('Received ' + currentMessages.length + ' messages!');

      // Separate the messages in respective variables
      this.errorMessages = currentMessages.filter(msg => msg.messageType === EnumMessageType.ERROR);
      this.warningMessages = currentMessages.filter(msg => msg.messageType === EnumMessageType.WARNING);
      this.infoMessages = currentMessages.filter(msg => msg.messageType === EnumMessageType.INFO);
    });
  }

  /**
   * Utility method to return the total message count.
   * Called in the template to show the error div.
   *
   */
  getMessagesCount(): number {
    return (this.errorMessages.length + this.warningMessages.length + this.infoMessages.length);
  }
}
