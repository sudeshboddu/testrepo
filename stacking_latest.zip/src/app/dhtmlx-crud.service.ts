import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DhtmlxCrudService {

  private messageSource = new BehaviorSubject<string[]>([]);
  currentSelectedDiscounts = this.messageSource.asObservable();

  constructor() { }

  changeSelectedDiscounts(selDiscs: string[]): void {
    console.log('Next w/ ' + selDiscs);
    console.log('Type : ' + selDiscs.length);
    this.messageSource.next(selDiscs);
  }
}
