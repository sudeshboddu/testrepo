/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AddRemoveBehaviorService } from './AddRemoveBehavior.service';

describe('Service: AddRemoveBehavior', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddRemoveBehaviorService]
    });
  });

  it('should ...', inject([AddRemoveBehaviorService], (service: AddRemoveBehaviorService) => {
    expect(service).toBeTruthy();
  }));
});
