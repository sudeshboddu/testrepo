import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import { AddRemove } from '../pojo/AddRemove';
/**
 *
 *
 * @export
 * @class AddRemoveBehaviorService
 */
@Injectable({
  providedIn: 'root'
})
export class AddRemoveBehaviorService {

constructor() { }


addBroadcastMessage =  new BehaviorSubject<AddRemove[]>([]);
private observableElement: Observable<AddRemove[]> ;

removeBroadCastMessage = new BehaviorSubject<number>(null);
private removeObservableElement: Observable<number>;

/**
 * Get an handle to the observable for add event. We will use this
 * to get the list of selected items.
 */
public getSubscription(): Observable<AddRemove[]> {

  if (this.observableElement == null) {
    this.observableElement = this.addBroadcastMessage.asObservable();
  }
    return this.observableElement;
 }

 /**
  * Use this to broadcast selected items.
  * @param selectedElement
  */
 public broadCast(selectedElement: AddRemove[]) {
  console.log('Going to broadcast the resposne ' + selectedElement);
 this.addBroadcastMessage.next(selectedElement);
}

/**
 *Observable element for remvoe functionality. Will be called
 * whenever the x button is clicked or remove all is clicked.
 *
 * @returns {Observable<string>}
 * @memberof AddRemoveBehaviorService
 */
public getRemoveSubscription(): Observable<number> {
  if (this.removeObservableElement == null) {
    this.removeObservableElement = this.removeBroadCastMessage.asObservable();
  }

  return this.removeObservableElement;
}

/**
 *broadcast the removed message
 *
 * @param {string} removedItem
 * @memberof AddRemoveBehaviorService
 */
public broadcastRemove(removedItem: number) {
  console.log('Broadcasting the removed item '+removedItem);
  this.removeBroadCastMessage.next(removedItem);
}

}
