/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { FileUploadBehaviorService } from './FileUploadBehavior.service';

describe('Service: FileUploadBehavior', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FileUploadBehaviorService]
    });
  });

  it('should ...', inject([FileUploadBehaviorService], (service: FileUploadBehaviorService) => {
    expect(service).toBeTruthy();
  }));
});
