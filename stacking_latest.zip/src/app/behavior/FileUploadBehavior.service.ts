import { Injectable } from '@angular/core';
import { FileUploadResponse } from '../pojo/FileUploadResponse';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
/**
 * BehaviorSubject for fileupload service.
 *
 * Current subscribers will be the
 *  - Grid - to refresh data once the file has been uploaded.
 *  - header alert - to show success/failure message
 * @export
 * @class FileUploadBehaviorService
 */
@Injectable({
  providedIn: 'root'
})


export class FileUploadBehaviorService {

constructor() { }
 statusBroadcastMessage = new BehaviorSubject<FileUploadResponse>(null);
 private observableElement: Observable<FileUploadResponse> ;
 private numb:number = 0;


 private subscription = this.getSubscription().subscribe(
  function (x) {
    if (x != null) {
      console.log('Next: ' + x.status);
    }
  },
  function (err) {
      console.log('Error: ' + err);
  },
  function () {
      console.log('Completed');
  });

/**
 *Get an instance of observable to listen to broadcasts
 *
 * @returns {Observable<FileUploadResponse>}
 * @memberof FileUploadBehaviorService
 */



public getSubscription(): Observable<FileUploadResponse> {
  console.log('I am getting called... ' + this.numb++);

  if (this.observableElement == null) {
    this.observableElement = this.statusBroadcastMessage.asObservable();
  }
    return this.observableElement;
 }




 /**
  * Has to be invoked, each time the upload process is complete.
  *
  * @param {FileUploadResponse} uploadResponse
  * @memberof FileUploadBehaviorService
  */
 public broadCast(uploadResponse: FileUploadResponse) {
   console.log('Going to broadcast the resposne ' + uploadResponse.batchId);
  this.statusBroadcastMessage.next(uploadResponse);
 }
}
