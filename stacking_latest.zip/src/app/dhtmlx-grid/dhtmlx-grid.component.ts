import { Component, OnInit, AfterContentInit, ElementRef } from '@angular/core';
import { DhtmlxCrudService } from '../dhtmlx-crud.service';

import { MOCK_GRID_DATA_JSON } from '../mock-data';
import { DcMessageService } from '../dc-message.service';
import { IMessage, EnumMessageType } from '../interfaces/imessage';

@Component({
  selector: 'app-dhtmlx-grid',
  templateUrl: './dhtmlx-grid.component.html',
  styleUrls: ['./dhtmlx-grid.component.css']
})
export class DhtmlxGridComponent implements OnInit, AfterContentInit {

  _theGrid: dhtmlXGridObject;
  selections: string[];
  disableSubmit: boolean = true;
  disableDelete: boolean = true;

  constructor(private crudSvc: DhtmlxCrudService, private msgSvc: DcMessageService, private elementRef: ElementRef) { }

  ngOnInit() {
    this.crudSvc.currentSelectedDiscounts.subscribe(currSelections => {
      console.log('Received :' + currSelections.length);
      for (let i = 0; i < currSelections.length; i++) {
        this._theGrid.addRow((this._theGrid.getRowsNum() + 1), '0,--,' + currSelections[i]);
      }
    });
  }

  ngAfterContentInit() {

    // let dhtmlx_image_path = 'assets/sources/dhtmlxGrid/codebase/imgs/dhxgrid_skyblue/';
    window['dhx_globalImgPath'] = 'assets/sources/dhtmlxGrid/codebase/imgs/dhxgrid_skyblue/';

    // const _theGrid: dhtmlXGridObject = new dhtmlXGridObject('gridbox');
    this._theGrid = new dhtmlXGridObject('gridbox');

    this._theGrid.setColSorting('na,str,str');
    this._theGrid.setHeader('#master_checkbox,Status,Scenarios'); // the headers of columns
    this._theGrid.setColTypes('ch,ro,ro');
    this._theGrid.setSkin('dhx_skyblue');
    this._theGrid.setInitWidths('35,55,*');
    this._theGrid.enablePaging(true, 10, 5, document.getElementById('gridboxPaging'), true, null);
    this._theGrid.enableResizing('false, false, false');
    this._theGrid.setPagingSkin('toolbar');
    this._theGrid.attachEvent('onCheck', (rowIdx, colIdx, state) => {
      this.changeDeleteSubmitButtonState(rowIdx, colIdx, state);
    });

    this._theGrid.init();
    this._theGrid.parse(MOCK_GRID_DATA_JSON, 'json'); // takes the name and format of the data source
    this._theGrid.setColSorting('na,na,str');
  }

  clearAll() {
    this._theGrid.clearAll(false);
  }

  sort() {
    console.log('Moved ...');
  }

  /**
   * Captures the user selection on the filter 'select' and propogates the selection to the
   * dhtmlxGrid's filterBy method. This is needed as the built in filter shows the entire
   * markup (text) in the dropdown list instead of the rendered image/spans
   */
  triggerProxyFilter() {
    // Get a reference to the 'proxyFilter' (one the user interacts with)
    const selectFilter = (<HTMLSelectElement> document.getElementById('proxyFilterSelect'));
    // Get the index of the option selected by user
    const selectedStatus = selectFilter.options[selectFilter.selectedIndex].value;

    // Filtering the content based on the user selection
    this._theGrid.filterBy(1, function (val) {
      switch(selectedStatus) {
        case 'VALID':
          return val.indexOf('green') !== -1;
        case 'INVALID':
          return val.indexOf('red') !== -1;
        case 'ALL':
          return true;
      }
    }, false);

    // Resetting the selections (clearing all)
    this._theGrid.uncheckAll();

    // Handling the master checkbox
    const masterCheckbox = <HTMLInputElement> (document.getElementById('gridbox')
                                                  .querySelector('.hdrcell').querySelector('input[type="checkbox"]'));
    masterCheckbox.checked = false;
    // Triggering the update of 'Submit' and 'Delete' buttons
    this.changeDeleteSubmitButtonState();
  }

  /**
   * Get the rows selected in the grid
   */
  getCheckedRows() {
    console.log(this._theGrid.getCheckedRows(0));
    return this._theGrid.getCheckedRows(0);
  }
  /**
   * Delete the rows selected by the user
   */
  deleteCheckedRows() {
    const checkedRows = this._theGrid.getCheckedRows(0);
    if (checkedRows.length > 0) {
      const checkedRowIds = checkedRows.split(',');

      for(const rowId of checkedRowIds) {
        this._theGrid.deleteRow(rowId);
      }
    }
  }

   /**
   * Called from the 'OnCheck' event handler code for dhtmlxgrid. Enables/Disables
   * the buttons as per the user selections on the grid.Marking the parameters as
   * optional as this will be called from other places in the code in addition to
   * the automatic call by the grid 'onChcek' event.
   *
   */
  changeDeleteSubmitButtonState(rowIdx?: number|string, colIdx?: number, state?: boolean): void {
    const checkedRows = this._theGrid.getCheckedRows(0);
    const submitButtonElement = this.elementRef.nativeElement.querySelector('#submitButton');
    const deleteButtonElement =  this.elementRef.nativeElement.querySelector('#deleteButton');

    if (checkedRows.length === 0) {
      this.disableDelete = true;
      this.disableSubmit = true;
      submitButtonElement.classList.add('icwButtonDisabled');
      deleteButtonElement.classList.add('icwButtonDisabled');
      return;
    }

    this.disableDelete = false;
    deleteButtonElement.classList.remove('icwButtonDisabled');

    const checkedRowIds = checkedRows.split(',');
    for (const rowId of checkedRowIds) {
      if (this._theGrid.cells(rowId, 1).getValue().indexOf('status-dot-red') !== -1) {
        this.disableSubmit = true;
        submitButtonElement.classList.add('icwButtonDisabled');
        return;
      }
    }

    this.disableSubmit = false;
    submitButtonElement.classList.remove('icwButtonDisabled');
  }
}
