// Enum for MessageType
export enum EnumMessageType {
    WARNING,
    ERROR,
    INFO
}

export interface IMessage {
    messageType?: EnumMessageType;
    messageCode?: string;
    messageDesc?: string;
}
