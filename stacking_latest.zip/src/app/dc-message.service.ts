import { IMessage, EnumMessageType } from './interfaces/imessage';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DcMessageService {

  _deferredMessages: IMessage[] = [];

  private messageSource = new BehaviorSubject<IMessage[]>([]);
  messages = this.messageSource.asObservable();

  constructor() { }

  /**
   * Method to display error messages.
   *
   * @param messages Array of messages (string) to be displayed.
   */
  showErrorMessages(messages: string[]): void {
    this.showTypedMessage(messages, EnumMessageType.ERROR);
  }

  /**
   * Method to display warning messages
   *
   * @param messages Array of messages (string) to be displayed.
   */
  showWarningMessages(messages: string[]): void {
    this.showTypedMessage(messages, EnumMessageType.WARNING);
  }

  /**
   * Method to display informartion messages.
   *
   * @param messages Array of messages (string) to be displayed.
   */
  showInfoMessages(messages: string[]): void {
    this.showTypedMessage(messages, EnumMessageType.INFO);
  }

  /**
   * Generic method called by the ohter convenience methods to display
   * messages of error/warning/info type.
   *
   * @param messages  Array of messages (string) to be displayed.
   * @param msgType Message type (EnumMessageType) for the messages.
   */
  private showTypedMessage(messages: string[], msgType: EnumMessageType): void {
    const messagesArr: IMessage[] = [];

    for (const msg of messages) {
      messagesArr.push(this.getTypedMessage(msgType, msg));
    }

    this.messageSource.next(messagesArr);
  }


  private getTypedMessage(msgType: EnumMessageType, messageDesc: string, messageCode?: string): IMessage {
    return { messageType: msgType, messageCode: messageCode, messageDesc: messageDesc };
  }
  /**
   * Method to display the error messages.
   * Please note that this method expects an array of 'IMessage' messages.
   *
   * @param messages
   */
  showMessages(messages: IMessage[]): void {
    const messagesArr: IMessage[] = [];
    for (const msg of messages) {
      messagesArr.push({ messageType: msg.messageType, messageCode: msg.messageCode, messageDesc: msg.messageDesc });
    }

    this.messageSource.next(messagesArr);
  }

  /**
   * Utility method to clear all messages.
   */
  clearMessages(): void {
    this.messageSource.next([]);
  }

  /**
   * Method to add a deferred message (to be displayed later).
   * Call 'showDeferredMessages()' to display all deferred messages.
   *
   * @param message Message string to be displayed.
   * @param messageType Message type.
   */
  addDeferredMessage(message: string, messageType: EnumMessageType): void {
    this._deferredMessages.push(this.getTypedMessage(messageType, message));
  }

  /**
   * Utility method to display all the messages that are stored in the deferred messages array.
   *
   */
  showDeferredMessages() {
    this.messageSource.next(this._deferredMessages);
  }

  /**
   * Utility method to clear all deferred messages.
   *\
   */
  clearDeferredMessages() {
    this._deferredMessages.length = 0;
    this.clearMessages();
  }

}
