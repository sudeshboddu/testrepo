import { Component, OnInit, AfterContentInit, Output, EventEmitter } from '@angular/core';
import { comboData } from '../../data';
import { Observable, Subject } from 'rxjs';
import { Routes, RouterModule, Router, ActivatedRoute, Params } from '@angular/router';
import { AddRemoveBehaviorService } from '../behavior/AddRemoveBehavior.service';
import { AddRemove } from '../pojo/AddRemove';

declare var dhtmlXCombo: any;

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})

export class DhtmlxComboComponent implements OnInit, AfterContentInit {
  myCombo : any;

//  public onCheck = true;

  constructor(private router: Router, private addRemoveBehaviorService: AddRemoveBehaviorService ) {

   }
  seletedRowList = []; // array to store selected values
  columns: string[];
  @Output()
  selectedRow:any =  new EventEmitter(); // selected values are emitted
  checkedList:any =  new EventEmitter(); // selected values are emitted

  ngOnInit() {
    this.addRemoveBehaviorService.getRemoveSubscription().subscribe(removedElement => {
      console.log('In combo, the remove element is '+removedElement);
      if (removedElement != null) {
        console.log('Removing element at index '+removedElement);
        this.myCombo.setChecked(removedElement, false);
      }
    });
  }

  ngAfterContentInit() {
      this.myCombo = new dhtmlXCombo('combo_zone', 'combo', 230, 'checkbox');
      this.myCombo.load(comboData);
      this.myCombo.enableFilteringMode(true);
      this.myCombo.attachEvent('onChange', function(value, text){
      //  this.onCheck = false;
      console.log('onChange event, value: ' + value + ', text: ' + text);
      });
      this.myCombo.attachEvent('onSelectionChange', function(){
        //  this.onCheck = false;
        console.log('onSelectionChange event');
        //  console.log("onCheck",this.onCheck)

      });

      this.myCombo.setPlaceholder('Search(Auto Complete)');
      this.setDefaultvalue();
  }

   testRefreshMethod(data) {
     console.log(data);
  }

  addDiscount(){
    const selection = this.myCombo.getChecked();
    this.seletedRowList = [];
    for (const discCodes of selection) {
      const elem = new AddRemove(discCodes, false);
      this.seletedRowList.push(elem);
    }

    console.log('Going to broadcast selected discounts.. ');
    this.addRemoveBehaviorService.broadCast(this.seletedRowList);
  }

  onRowSelected(){
    this.selectedRow.emit(this.seletedRowList);
  }

  setDefaultvalue(){
    //  this.seletedRowList.push( "BR-5678(US-Teaming Plus)");
    this.selectedRow.emit(this.seletedRowList);
  }

  // Empty the selectedRow array

  onRemoveAll(){
  // var temp = "BR-5678(US-Teaming Plus)";
    this.selectedRow.emit( [] );
    this.myCombo.load(comboData);
  }

}
