export interface uploadResponse {
    id:string,
    status:string,
    statusMessage:string
}