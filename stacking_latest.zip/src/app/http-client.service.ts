import { IMenuData } from './imenu-data';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../src/environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class HttpClientService {

  constructor(private httpClient: HttpClient) { }

  public getMenuData(userId?: string): Observable<IMenuData> {
    // const _MENU_SERVICE_URL = 'http://localhost:3000/api/menu';
    const _MENU_SERVICE_URL = window.location.origin+"/discen/loadmenu/getMenudata.do";
    console.log('TEST :' + window.location.origin);
    console.log('Getting menu data from ' + _MENU_SERVICE_URL);
    return this.httpClient.get<IMenuData>(_MENU_SERVICE_URL);
  }

}
