import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dc-footer',
  templateUrl: './dc-footer.component.html',
  styleUrls: ['./dc-footer.component.css']
})
export class DcFooterComponent implements OnInit {

  currentYear: number = new Date().getFullYear();

  constructor() { }

  ngOnInit() {
  }

}
