export class FileUploadResponse {

   batchId: number;
   status: string;
   result: string;
  constructor(
     batchId: number,
     status: string,
     result: string
  ) {
    this.batchId = batchId;
    this.status = status;
    this.result = result;
  }
}
