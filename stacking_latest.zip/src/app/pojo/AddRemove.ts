export class AddRemove {
  discountCode: string;
  isPivot = false;

  constructor(
    discountCode: string,
    isPivot: boolean
 ) {
   this.discountCode = discountCode;
   this.isPivot = isPivot;
 }
}
