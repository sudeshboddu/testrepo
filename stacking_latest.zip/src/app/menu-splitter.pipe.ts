import { Pipe, PipeTransform } from '@angular/core';
/**
 * Custom pipe created to split the menu entries in two columns. Default column size is 6. If there are more
 * than 6 entries, the list is split into two columns.
 */
@Pipe({
  name: 'menuSplitter'
})
export class MenuSplitterPipe implements PipeTransform {
  /**
   * Handling the transformation here
   * @param array
   */
  transform(array: object[]): object[] {
    const result = [];
    let chunkSize = 6; // Default size set to 6

    // If the number of items is more than 12
    // splitting them into separate arrays
    if (array && array.length > 12) {
      if (array.length % 2 === 1) {
        chunkSize = (array.length + 1) / 2;
      } else {
        chunkSize = array.length / 2;
      }
    }

    // Populating the resulting array.
    if (array) {
      for (let i = 0, j = array.length; i < j; i += chunkSize) {
        result.push(array.slice(i, i + chunkSize));
      }
    }

    // Returning the new array
    return result;
  }
}
