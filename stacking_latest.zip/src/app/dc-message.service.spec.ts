import { TestBed, inject } from '@angular/core/testing';

import { DcMessageService } from './dc-message.service';

describe('DcMessageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DcMessageService]
    });
  });

  it('should be created', inject([DcMessageService], (service: DcMessageService) => {
    expect(service).toBeTruthy();
  }));
});
