import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { AddRemoveBehaviorService } from '../behavior/AddRemoveBehavior.service';
import { AddRemove } from '../pojo/AddRemove';

@Component({
  selector: 'app-stacking',
  templateUrl: './stacking.component.html',
  styleUrls: ['./stacking.component.css']
})
export class StackingComponent implements OnInit {

  pivotDiscountCode: string;
  pivotDiscountId:string;
  constructor(private route: ActivatedRoute, private addRemoveBehaviorService: AddRemoveBehaviorService) {

    this.route.queryParams.subscribe(params => {
      this.pivotDiscountCode = params['discountCode'];
      this.pivotDiscountId = params['discountId'];

      console.log("The pivot discount code is "+ this.pivotDiscountCode);

      const elem: AddRemove = new AddRemove(this.pivotDiscountCode, true);
      addRemoveBehaviorService.broadCast([elem]);
  });
   }

  ngOnInit() {
  }

}
