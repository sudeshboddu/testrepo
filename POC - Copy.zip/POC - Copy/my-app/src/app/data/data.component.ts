import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {

  testTable= [];
  constructor() { }

  ngOnInit() {
  }

  slectedRow(selectedRow){
    this.testTable = selectedRow;
  }

}
