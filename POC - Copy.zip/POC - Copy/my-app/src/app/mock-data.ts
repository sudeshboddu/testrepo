export const CHARACTERS: any[] =
[
  {
    discount: 'BR-5678(US-Teaming Plus)'
  },
  {
    discount: 'BA-ACC1(Accelerator-1)'
  },
  {
    discount: 'BA-ACC2(Accelerator-2)'
  },
  {
    discount: 'BR-1234(US-OIP)'
  }
]