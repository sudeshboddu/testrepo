import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DhtmlGridComponent } from './dhtml-grid.component';

describe('DhtmlGridComponent', () => {
  let component: DhtmlGridComponent;
  let fixture: ComponentFixture<DhtmlGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DhtmlGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DhtmlGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
