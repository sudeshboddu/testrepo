import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dhtml-grid',
  templateUrl: './dhtml-grid.component.html',
  styleUrls: ['./dhtml-grid.component.css']
})
export class DhtmlGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
