import { Component, OnInit, AfterContentInit, Output, EventEmitter } from '@angular/core';
import { comboData } from '../../data';
import { Observable, Subject } from 'rxjs';
import { AdventureTimeService } from '../adventure-time.service';
import { Routes, RouterModule, Router, ActivatedRoute, Params } from '@angular/router';

declare var dhtmlXCombo: any;

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})

export class DhtmlxComboComponent implements OnInit, AfterContentInit {
  myCombo : any;
  public seletedRowList = []; // array to store selected values

//  public onCheck = true;

public static refreshComboboxData: Subject<any> = new Subject();
  constructor(private atService: AdventureTimeService,private router: Router,
      private activatedRoute: ActivatedRoute) {
    DhtmlxComboComponent.refreshComboboxData.subscribe((data)=>{
      debugger;
    //  this.testRefreshMethod(data);
      var index = this.myCombo.getIndexByValue(data);
      this.myCombo.setChecked(index, false);

    });
   }

  columns: string[];
  @Output()
  selectedRow:any =  new EventEmitter(); //selected values are emitted
  checkedList:any =  new EventEmitter(); //selected values are emitted

  ngOnInit() {
    this.activatedRoute.params.subscribe((params: Params) => {
        console.log("param",params);
        let route = this.router.navigate(['/discounts'], { queryParams: { order: 'list' } });
        console.log("param",route);

        this.route.queryParams
        .filter(params => params.order)
        .subscribe(params => {
        console.log(params); // {order: "list"}

        this.order = params.order;
        console.log(this.order); // list

        this.route.queryParamMap.subscribe(params => {
        this.orderObj = {...params.keys, ...params};
        });
        });
      }
  }

  goList() {
      let route = this.router.navigate(['/products'], { queryParams: { order: 'popular' } });
      console.log("param",route);
  }

  ngAfterContentInit() {
      this.myCombo = new dhtmlXCombo("combo_zone", "combo", 230, "checkbox");
      this.myCombo.load(comboData);
      this.myCombo.enableFilteringMode(true);
      this.myCombo.attachEvent("onChange", function(value, text){
      //  this.onCheck = false;
				console.log("onChange event, value: "+value+", text: "+text);
			});
      this.myCombo.attachEvent("onSelectionChange", function(){
        //  this.onCheck = false;
        console.log("onSelectionChange event");
        //  console.log("onCheck",this.onCheck)

      });

      this.myCombo.setPlaceholder("Search(Auto Complete)");
      this.setDefaultvalue();

  }

  // testRefreshMethod(data){
  //   console.log(data);
  // }
  //
  // addDiscount(){ // to get the selected values from combo
  //   var selection = this.myCombo.getChecked();
  //   //allow to capture selected data
  //   this.seletedRowList = selection;
  //   this.selectedRow.emit(selection);
  //
  //  // Reload the combo data
  //  // this.myCombo.load(comboData);
  //  // var test = this.myCombo.load(comboData);
  //  // console.log("test",test)
  // }
    addDiscount(){
  var selection = this.myCombo.getChecked();
  //allow to capture selected data
  //this.seletedRowList = selection;
  this.seletedRowList = selection.push(this.selectedRow);
  this.selectedRow.emit(selection);
  }
  onRowSelected(){
    this.selectedRow.emit(this.seletedRowList);
  }

  setDefaultvalue(){
    this.seletedRowList.push( "BR-5678(US-Teaming Plus)");
    this.selectedRow.emit(this.seletedRowList);
  }

  // Empty the selectedRow array
  // onRemoveAll(){
  // // this.selectedRow.emit([]);
  // this.seletedRowList.splice(1);
  // }

  onRemoveAll(){
  // this.selectedRow.emit([]);
  this.seletedRowList.splice(1);
  this.myCombo.load(comboData);
  }

}
