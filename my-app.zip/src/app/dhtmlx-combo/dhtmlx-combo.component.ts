import { Component, OnInit, AfterContentInit} from '@angular/core';
import { comboData } from '../../data';
declare var dhtmlXCombo: any;
//declare var dhtmlXComboFromSelect: any;

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})

export class DhtmlxComboComponent implements OnInit, AfterContentInit {
  myCombo : any;
  constructor() { }

  ngOnInit() {
  }

  ngAfterContentInit() {
      //var myCombo2 ;
      this.myCombo = new dhtmlXCombo("combo_zone", "combo", 230, "checkbox");
      this.myCombo.load(comboData);
      this.myCombo.enableFilteringMode(true);
      //myCombo2 = dhtmlXComboFromSelect("mySelect");
  }

}
