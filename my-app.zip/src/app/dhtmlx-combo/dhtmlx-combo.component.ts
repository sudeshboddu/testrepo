import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})
export class DhtmlxComboComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    var myCombo, myCombo2;
  //	function doOnLoad() {
      myCombo = new dhtmlXCombo("combo_zone", "combo", 230, "checkbox");
      myCombo.load("../common/data2.json");
      myCombo.enableFilteringMode(true);
      //
      myCombo2 = dhtmlXComboFromSelect("mySelect");
  //	}
  }

}
