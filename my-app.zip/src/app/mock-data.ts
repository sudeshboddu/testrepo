export const CHARACTERS: any[] =
[
  {
    discount: 'BR-5678(US-Teaming Plus)'
  },
  {
    discount: 'BA-ACC1(Accelerator-1)'
  },
  {
    discount: 'BA-ACC2(Accelerator-2)'
  },
  {
    discount: 'BR-1234(US-OIP)'
  },
  {
    discount: 'BR-2345(US-TIP)'
  },
  {
    discount: 'BR-3468(US-SIP)'
  },
  {
    discount: 'BR-7890(US-Teaming)'
  },
  {
    discount: 'CD-Moto-114436(US Motorola)'
  },
  {
    discount: 'CD-Anom-115799(Anomli STI US)'
  }
]

// [
//   {
//   	"discountName":"AAA",
//   	"discountType":"BR",
//   	"discountCode":"xyz",
//   	"discountId":1234
//   }
// ]  BR-xyz(AAA)
