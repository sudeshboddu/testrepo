/*
Product Name: dhtmlxGrid 
Version: 5.1.0 
Edition: Professional 
License: content of this file is covered by DHTMLX Commercial or Enterprise license. Usage without proper license is prohibited. To obtain it contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

/*
	@author dhtmlx.com
	@license GPL, see license.txt
*/

if (window.dataProcessor && !dataProcessor.prototype.init_original)
	dataProcessor.prototype.connector_init=true;

