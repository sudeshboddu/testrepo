
export const comboData =
{
	options: [
		{value: "BR-5678(US-Teaming Plus)", text: "BR-5678(US-Teaming Plus)"},
		{value: "BA-ACC1(Accelerator-1)", text: "BA-ACC1(Accelerator-1)"},
		{value: "BA-ACC2(Accelerator-2)", text: "BA-ACC2(Accelerator-2)"},
		{value: "BR-1234(US-OIP)", text: "BR-1234(US-OIP)"},
		{value: "'BR-2345(US-TIP)", text: "'BR-2345(US-TIP)"},
		{value: "BR-3468(US-SIP)", text: "BR-3468(US-SIP)"},
		{value: "BR-7890(US-Teaming)", text: "BR-7890(US-Teaming)"},
		{value: "CD-Moto-114436(US Motorola)", text: "CD-Moto-114436(US Motorola)"},
		{value: "CD-Anom-115799(Anomli STI US)", text: "CD-Anom-115799(Anomli STI US)"}
	]
};
