import { Component, OnInit, AfterContentInit } from '@angular/core';

declare var dhtmlXCombo: any;

@Component({
  selector: 'app-dhtmlx-combo',
  templateUrl: './dhtmlx-combo.component.html',
  styleUrls: ['./dhtmlx-combo.component.css']
})
export class DhtmlxComboComponent implements OnInit, AfterContentInit {

  _combo: any;

  constructor() { }

  ngOnInit() {
  }

  ngAfterContentInit() {
    window['dhx_globalImgPath'] = '../../assets/ext/dhtmlxCombo/codebase/imgs/';
    const theCombo = new dhtmlXCombo('combo_zone', 'combo', 230, 'checkbox');
    theCombo.enableFilteringMode(true);
    theCombo.loadXML('http://localhost:3000/api/comboData');

    this._combo = theCombo;
  }

  getChecked() {
    return this._combo.getChecked();
  }
}
