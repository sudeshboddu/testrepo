import { Component, OnInit, AfterContentInit, Input, Output } from '@angular/core';
import { Http } from '@angular/http';
import { ReadDataService } from '../read-data.service';
import { EventEmitter } from 'events';

declare var dhtmlXGridObject: any;

@Component({
  selector: 'app-dhtmlx-grid',
  templateUrl: './dhtmlx-grid.component.html',
  styleUrls: [
    '../../assets/ext/dhtmlxGrid/codebase/dhtmlxgrid.css',
    '../../assets/ext/dhtmlxToolbar/codebase/skins/dhtmlxtoolbar_dhx_skyblue.css'
  ]
})
export class DhtmlxGridComponent implements OnInit, AfterContentInit {
  private theGrid: any;
  private numRows: number;
  private numColumns: number;
  private numTables: number;
  private rowsPerPage: number;
  private data: any[];
  private colDef: any[];
  private colWidth: any[];
  private colAlign: any[];
  private colTypes: any[];
  private colNames: any[];
  private eXcell_details: any;
  private showStyle = true;

  @Input() gridBoxId: string;
  @Input() toolBarId: string;
  @Input() headerLabels: string;
  @Input() columnTypes: string;
  @Input() columnWidths: string;
  @Input() columnAlignments: string;
  @Input() columnSort: string;

  @Output() xleEvent: EventEmitter = new EventEmitter();
  @Output() xlsEvent: EventEmitter = new EventEmitter();

  constructor() {
        this.numRows = 20;
        this.numTables = 1;
        this.rowsPerPage = 10;
        this.colNames = [
            'NAME,CEC ID,CITY'
        ];
        this.data = [];
        this.colDef = [];
        this.colWidth = ['100,200,*'];
        this.colAlign = [];
        this.colTypes = [];
        this.numColumns = this.colNames.length;
        this.createColumnDef();
        this.createData();
        // this.eXcell_details = new eXcell_details();
        console.log('Constructor done');
  }

  ngOnInit() {
  }


  ngAfterContentInit() {
    console.log('Init : Init with GridBox Id : ' + this.gridBoxId + ' -- ' + this.headerLabels);
    const theGrid = new dhtmlXGridObject(this.gridBoxId);

    const zdata = [
      ['<a href="#">Test Promo 1</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 2</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'GREATER CHINA', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 3</a>', 'PP-Test-180430-04583', 'PROMOTION', 'INPROGRESS', 'EMEAR', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 3</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Contractual 5</a>', 'CD-Test-180430', 'CONTRACTUAL', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 6</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 7</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 8</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'APJ', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 9</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 10</a>', 'BR-Test-180430-04583', 'REWARD', 'REJECTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 11</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 12</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Contractual 13</a>', 'CD-Test-1883', 'CONTRACTUAL', 'INPROGRESS', 'APJ', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 14</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 15</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'EMEAR', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 16</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 17</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Reward 18</a>', 'BR-Test-180430-04583', 'REWARD', 'ACTIVE', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--'],
      ['<a href="#">Test Promo 19</a>', 'PP-Test-180430-04583', 'PROMOTION', 'SUBMITTED', 'AMERICAS', '27-Apr-2018', '31-Apr-2022', '--']
    ];

    theGrid.setImagePath('../../assets/ext/dhtmlxGrid/codebase/imgs/');
    theGrid.setHeader(this.headerLabels);
    theGrid.setInitWidths(this.columnWidths);
    theGrid.setColAlign(this.columnAlignments);
    theGrid.setColTypes(this.columnTypes);
    theGrid.setColSorting(this.columnSort);
    theGrid.setSkin('dhx_skyblue');
    theGrid.enablePaging(true, 10, 5, this.toolBarId);
    theGrid.setPagingSkin('toolbar', 'dhx_skyblue');

    theGrid.setColumnHidden(7, true);

    theGrid.attachEvent('onXLE', this.xleEvent.emit(null));
    theGrid.attachEvent('onXLS', this.xlsEvent.emit(null));

    theGrid.init();

    // theGrid.parse(this.dataService.getData());
    theGrid.parse(zdata, 'jsarray');
    //
    // theGrid.parse(`../../assets/xml/data.xml`);
    this.xleEvent.emit(null);

  }

  onXleEvent(e) {
    console.log('Called');
  }

  onXlsEvent(e) {
    console.log('Called');
  }

  getStyle() {
    if (this.showStyle) {
        return 'yellow';
    } else {
        return '';
    }
  }

  private createData() {
    for (let j = 0; j < this.numRows; j++) {
        const time = new Date(new Date().getTime() + (j * (24 * 60 * 60 * 1000)));
        const valObj: any[] = [];
        for (let i = 0; i < this.numColumns; i++) {
            const val = Math.floor(Math.random() * (7710000 - 1710000) + 1710000) + ',A,B,C';
            valObj.push(`${val}`);
        }
       // console.log(valObj);
        this.data.push(valObj);
    }
  }

  private createColumnDef() {
      for (let i = 0; i < this.colNames.length; i++) {
          this.colDef.push('int');
          this.colWidth.push(100);
          this.colAlign.push('left');
          this.colTypes.push('edn');
      }
      this.colTypes[this.colTypes.length - 1] = 'details';
  }


}
