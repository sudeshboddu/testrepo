/*
Product Name: dhtmlxSuite 
Version: 5.1.0 
Edition: Professional 
License: content of this file is covered by DHTMLX Commercial or Enterprise license. Usage without proper license is prohibited. To obtain it contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

dhtmlXCalendarObject.prototype.draw = function() {
	this.show();
};
dhtmlXCalendarObject.prototype.close = function() {
	this.hide();
};
dhtmlXCalendarObject.prototype.setYearsRange = function() {
	
};

