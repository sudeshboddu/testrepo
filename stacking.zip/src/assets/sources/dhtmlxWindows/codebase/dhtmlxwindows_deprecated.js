/*
Product Name: dhtmlxSuite 
Version: 5.1.0 
Edition: Professional 
License: content of this file is covered by DHTMLX Commercial or Enterprise license. Usage without proper license is prohibited. To obtain it contact sales@dhtmlx.com
Copyright UAB Dinamenta http://www.dhtmlx.com
*/

dhtmlXWindows.prototype.enableAutoViewport = function(){};
dhtmlXWindows.prototype.setImagePath = function(){};
dhtmlXWindows.prototype.setEffect = function(){};
dhtmlXWindows.prototype.getEffect = function(){};

dhtmlXWindowsCell.prototype.setToFullScreen = function(){};
dhtmlXWindowsCell.prototype.setIcon = function(){};
dhtmlXWindowsCell.prototype.getIcon = function(){};
dhtmlXWindowsCell.prototype.restoreIcon = function(){};
dhtmlXWindowsCell.prototype.clearIcon = function(){};


