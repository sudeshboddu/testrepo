import { DhtmlxGridComponent } from './dhtmlx-grid/dhtmlx-grid.component';
import { HttpClientService } from './http-client.service';
import { FileUploaderServiceService } from './file-uploader/file-uploader-service.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { MenuSplitterPipe } from './menu-splitter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app.routing';
import { ErrorComponent } from './error/error.component';
import { StackingComponent } from './stacking/stacking.component';
import { FileUploaderComponent } from './file-uploader/file-uploader.component';
import { DcModalComponent } from './dc-modal/dc-modal.component';
import { FormsModule } from '@angular/forms';
import { DataComponent } from './data/data.component';
import { DhtmlxComboComponent } from './dhtmlx-combo/dhtmlx-combo.component';
import { DcFooterComponent } from './dc-footer/dc-footer.component';


@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    MenuSplitterPipe,
    ErrorComponent,
    StackingComponent,
    FileUploaderComponent,
    DcModalComponent,
    DataComponent,
    DhtmlxComboComponent,
    DhtmlxGridComponent,
    DcFooterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [ HttpClientService,FileUploaderServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
