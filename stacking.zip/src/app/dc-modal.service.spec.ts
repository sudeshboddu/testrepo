import { TestBed, inject } from '@angular/core/testing';

import { DcModalService } from './dc-modal.service';

describe('DcModalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DcModalService]
    });
  });

  it('should be created', inject([DcModalService], (service: DcModalService) => {
    expect(service).toBeTruthy();
  }));
});
