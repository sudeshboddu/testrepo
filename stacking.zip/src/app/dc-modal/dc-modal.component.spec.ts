import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DcModalComponent } from './dc-modal.component';

describe('DcModalComponent', () => {
  let component: DcModalComponent;
  let fixture: ComponentFixture<DcModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DcModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
