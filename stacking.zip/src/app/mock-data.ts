export const MOCK_GRID_DATA_JSON = {
  rows : [
     {
        id : 1,
        data : [
           '0',
           '<span class="status-dot status-dot-red"></span>',
           'BR-Test-180430-04583 (Name goes here) + BR-Test-180430-04583 + BR-Test-180430-04583 + BR-Test-180430-04583',
           'REWARD',
           'ACTIVE',
           'GREATER CHINA',
           '27-Apr-2018',
           '31-Apr-2022',
           '--'
        ]
     },
     {
        id : 2,
        data : [
           0,
           '<span class="status-dot status-dot-green"></span>',
           'PP-Test-180430-04583 + BR-Test-180430-04583  + BR-Test-180430-04583',
           'PROMOTION',
           'INPROGRESS',
           'EMEAR',
           '27-Apr-2018',
           '31-Apr-2022',
           '--'
        ]
     },
     {
        id : 3,
        data : [
           0,
           '<span class="status-dot status-dot-red"></span>',
           'BR-Test-180430-04583 + BR-Test-180430-04583',
           'REWARD',
           'ACTIVE',
           'AMERICAS',
           '27-Apr-2018',
           '31-Apr-2022',
           '--'
        ]
     },
     {
        id : 4,
        data : [
           0,
           '<span class="status-dot status-dot-green"></span>',
           'CD-Test-180430-04678 + BR-Test-180430-04583 + BR-Test-180430-04583 + BR-Test-180430-04583 + BR-Test-180430-04583',
           'CONTRACTUAL',
           'SUBMITTED',
           'AMERICAS',
           '26-May-2018',
           '31-Apr-2022',
           '--'
        ]
     }
  ]
};
