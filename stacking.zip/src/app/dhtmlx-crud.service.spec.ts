import { TestBed, inject } from '@angular/core/testing';

import { DhtmlxCrudService } from './dhtmlx-crud.service';

describe('DhtmlxCrudService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DhtmlxCrudService]
    });
  });

  it('should be created', inject([DhtmlxCrudService], (service: DhtmlxCrudService) => {
    expect(service).toBeTruthy();
  }));
});
