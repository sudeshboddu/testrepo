import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DcModalService {

  constructor() { }

  /**
   * Array to keep track of the modals created.
   */
  private modals: any[] = [];

  /**
   * Add modal to the list of modals being tracked.
   * @param modal
   */
  add(modal: any) {
    this.modals.push(modal);
  }

  /**
   * Remove the modal from the tracked list.
   * @param id
   */
  remove(id: string) {
    this.modals = this.modals.filter(mdl => mdl.id !== id);
  }

  /**
   * Open the modal identified by 'id'.
   * @param id
   */
  open(id: string) {
    const modal: any = this.modals.filter(mdl => mdl.id === id)[0];
    modal.open();
  }

  /**
   * Close the modal identified by 'id'.
   * @param id
   */
  close(id: string) {
    const modal: any = this.modals.filter(mdl => mdl.id === id)[0];
    modal.close();
  }
}
