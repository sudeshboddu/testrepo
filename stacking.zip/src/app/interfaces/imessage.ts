export enum MessageType {
    WARNING,
    ERROR
}

export interface IMessage {
    messageType?: MessageType;
    messageCode?: string;
    messageDesc?: string;
}
