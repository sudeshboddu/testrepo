import { Component, OnInit, AfterContentInit, ElementRef } from '@angular/core';
import { DhtmlxCrudService } from '../dhtmlx-crud.service';

import { MOCK_GRID_DATA_JSON } from '../mock-data';

@Component({
  selector: 'app-dhtmlx-grid',
  templateUrl: './dhtmlx-grid.component.html',
  styleUrls: ['./dhtmlx-grid.component.css']
})
export class DhtmlxGridComponent implements OnInit, AfterContentInit {

  _theGrid: dhtmlXGridObject;
  selections: string[];

  constructor(private crudSvc: DhtmlxCrudService, private elementRef: ElementRef) { }

  ngOnInit() {
    this.crudSvc.currentSelectedDiscounts.subscribe(currSelections => {
      console.log('Received :' + currSelections.length);
      for (let i = 0; i < currSelections.length; i++) {
        this._theGrid.addRow((this._theGrid.getRowsNum() + 1), '0,--,' + currSelections[i]);
      }
    });
  }

  ngAfterContentInit() {

    // let dhtmlx_image_path = 'assets/sources/dhtmlxGrid/codebase/imgs/dhxgrid_skyblue/';
    window['dhx_globalImgPath'] = 'assets/sources/dhtmlxGrid/codebase/imgs/dhxgrid_skyblue/';

    // const _theGrid: dhtmlXGridObject = new dhtmlXGridObject('gridbox');
    this._theGrid = new dhtmlXGridObject('gridbox');

    this._theGrid.setColSorting('na,str,str');
    this._theGrid.setHeader('#master_checkbox,Status,Scenarios'); // the headers of columns
    this._theGrid.setColTypes('ch,ro,ro');
    this._theGrid.setSkin('dhx_skyblue');
    this._theGrid.setInitWidths('35,55,*');
    // this._theGrid.makeFilter('hiddenStatusFilter', 1, false); // Registering a custom filter
    this._theGrid.enablePaging(true, 10, 5, document.getElementById('gridboxPaging'), true, null);
    this._theGrid.setPagingSkin('toolbar');
    this._theGrid.init();
    this._theGrid.parse(MOCK_GRID_DATA_JSON, 'json'); // takes the name and format of the data source
    this._theGrid.setColSorting('str,str,str,str,str,str,str,str');
    this._theGrid.setColumnHidden(8, true);
  }

  clearAll() {
    this._theGrid.clearAll(false);
  }

  sort() {
    console.log('Moved ...');
  }

  /**
   * Captures the user selection on the filter 'select' and propogates the selection to the
   * dhtmlxGrid's filterBy method. This is needed as the built in filter shows the entire
   * markup (text) in the dropdown list instead of the rendered image/spans
   */
  triggerProxyFilter() {
    // Get a reference to the 'proxyFilter' (one the user interacts with)
    const selectFilter = (<HTMLSelectElement> document.getElementById('proxyFilterSelect'));
    // Get the index os the option selected by user
    const selectedStatus = selectFilter.options[selectFilter.selectedIndex].value;

    // Filtering the content based on the user selection
    this._theGrid.filterBy(1, function (val) {
      switch(selectedStatus) {
        case 'VALID':
          return val.indexOf('green') !== -1;
        case 'INVALID':
          return val.indexOf('red') !== -1;
        case 'ALL':
          return true;
      }
    }, false);
  }


  getCheckedRows() {
    console.log(this._theGrid.getCheckedRows(0));
    return this._theGrid.getCheckedRows(0);
  }
}
