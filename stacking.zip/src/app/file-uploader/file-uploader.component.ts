import { DcModalService } from './../dc-modal.service';
import { Component, OnInit } from '@angular/core';
import { FileUploaderServiceService } from  './file-uploader-service.service';
import {FormsModule}  from '@angular/forms';
@Component({
  selector: 'app-file-uploader',
  templateUrl: './file-uploader.component.html',
  styleUrls: ['./file-uploader.component.css']
})
export class FileUploaderComponent implements OnInit {

  uploadType = 'Add';
  constructor(private fileUploaderService: FileUploaderServiceService, private dcModalService: DcModalService) { }

  private fileToUpload: File = null;
  ngOnInit() {
  }

/**
 * Function that will be called when file upload is invoked.
 * @param files
 */
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);

    if (this.fileToUpload == null) {
      return;
    }
    console.log('upload file event name is ' + this.fileToUpload.name);
}


uploadFileToActivity(uploadType) {

  console.log('The upload type is ' + uploadType);
if (this.fileToUpload == null) {
  return;
}
  if (!this.fileToUpload.name.endsWith('xls') && (!this.fileToUpload.name.endsWith('xlsx'))) {
    console.error('invalid fle name given');
    this.dcModalService.open('alert-modal');
  }

  this.fileUploaderService.postFile(this.fileToUpload, uploadType, 'BR-12345').subscribe(data => {
    // do something, if upload success
    }, error => {
      console.log(error);
    });
}
}
