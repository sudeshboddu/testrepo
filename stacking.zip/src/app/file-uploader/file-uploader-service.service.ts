import { Observable} from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';


// A class member cannot have a const variable. Moving it outside.
//{ 'Content-Type': 'multipart/form-data', 'Access-Control-Allow-Origin': '*' }
const headers = new HttpHeaders().set("Access-Control-Allow-Origin","*");
headers.set("Content-Type","multipart/form-data");


@Injectable()
export class FileUploaderServiceService {




  constructor(private httpClient: HttpClient) {
  }


  postFile(fileToUpload: File, actionEvent: string, pivotCode: string): Observable<boolean> {
    const endpoint = '/discen/rest/scenarioUpload/createScenario.do';
    const formData: FormData = new FormData();
    formData.append('fileKey', fileToUpload, fileToUpload.name);
    formData.append('actionEvent',actionEvent);
    formData.append('pivotCode',pivotCode);
 let contentTypeValue :string = "multipart/form-data";

    // if (fileToUpload.name.endsWith("xls")) {
    //   contentTypeValue = "application/vnd.ms-excel";
    // }
 //   let contentTypeValue :string = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";



    return this.httpClient
      .post(endpoint, formData,{headers:{'Access-Control-Allow-Origin': '*'}})
      .pipe(map(() => { return true; }))
      .pipe(catchError((err:any)=> this.handleError(err)));
   //   .pipe(catchError((err: any, caught: Observable<boolean>) => this.handleError(err)));
}

handleError(err: any) {
  console.error("Exception while uploading the file " + err);
  return Observable.throw(err.code);
}
}
