import { DhtmlxComboComponent } from './../dhtmlx-combo/dhtmlx-combo.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})

export class DataComponent implements OnInit {

  listTable= []; //storing emitting value
  checkedTable= [];
  constructor() { }

  ngOnInit() {
  }

  slectedRow(selectedRow){ //capturing the emitted selectedRow value.
    this.listTable = selectedRow;
  }

  checkedList(checkedList){ //capturing the emitted selectedRow value.
    this.checkedTable = checkedList;
  }

  // table a copying from table b, deleting value from selectedRow
  deleteOnImageClick(item){
    let index = this.listTable.indexOf(item);
    if(index > -1){
      this.listTable.splice(index, 1);
      DhtmlxComboComponent.refreshComboboxData.next(item);
    }
  }

}
