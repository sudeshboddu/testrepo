import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable()
export class MessengerServiceService {

  _isOpen = false;

  @Output() change: EventEmitter <boolean> =  new EventEmitter <boolean>();

  constructor() { }

  toggle() {
    this._isOpen = !this._isOpen;
    this.change.emit(this._isOpen);
  }

}
