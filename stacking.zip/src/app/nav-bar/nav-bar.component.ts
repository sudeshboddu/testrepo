import { HttpClientService } from './../http-client.service';
import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs';

import * as $ from 'jquery';
import { IMenuData } from '../imenu-data';
import { DcModalService } from '../dc-modal.service';
/**
 * This is the main 'navigation-bar' component for Discount Central Application (modeled after the menu in the legacy web-app).
 * Currently the data for the meu entries is fetched from the injected httpService {@link HttpClientService }
 * @author Ashish Agnihotri (aagnihot)
 */
@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  public menuData: IMenuData;

  @Input() subTitleText: string;

  constructor(private __httpService: HttpClientService, private dcModalService: DcModalService) { }

  ngOnInit() {
    this.getMenuData();
    sessionStorage.setItem('dnt', new Date() + '');
  }

  showProfile(id: string) {
    console.log('Display Profile dialog here ...');
    this.dcModalService.open(id);
  }

  hideProfile(id: string) {
    this.dcModalService.close(id);
  }

  hideAlert(id: string) {
    this.dcModalService.close(id);
  }

  showAlert(id: string) {
    console.log('Display Profile dialog here ...');
    this.dcModalService.open(id);
  }

  getMenuData() {
       this.__httpService.getMenuData().subscribe(
          data => { this.menuData = data; },
          err => console.error(err),
          () => { console.log('Done loading menu data ...');
                  console.dir(this.menuData);
                }
        );
    }

  toggleProfile() {
    console.log('TBD');
  }
}