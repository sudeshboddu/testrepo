import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stacking',
  templateUrl: './stacking.component.html',
  styleUrls: ['./stacking.component.css']
})
export class StackingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
