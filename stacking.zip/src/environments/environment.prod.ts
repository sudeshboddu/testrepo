export const environment = {
  production: true,
  getMenuServiceUrl: 'http://localhost:3000/api/menu?qa'
};
