/*
 * @license
 * Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

function truthy(val) {
    // test if value is not null or empty
    if (val) {
        switch (typeof val) {
            case 'object':
                return !_.isEmpty(val);
            case 'string':
                return !_.isEmpty(_.trim(val));

            default:
                return true;
        }
    } else {
        return false;
    }

}

// test cases
// console.log('null', truthy(null));
// console.log('""', truthy(''));
// console.log('" "', truthy(' '));
// console.log(0, truthy(0));
// console.log(55, truthy(55));
// console.log('"0"', truthy('0'));
// console.log(false, truthy(false));
// console.log([], truthy([]));
// a = {
//     'key': 1
// };
// console.log({}, truthy({}));
// console.log(a, truthy(a));
// console.log(a.b, truthy(a.b));

function convertDataURIToBinary(dataURI) {
    var BASE64_MARKER = ';base64,';
    var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
    var base64 = dataURI.substring(base64Index);
    var raw = window.atob(base64);
    var rawLength = raw.length;
    var array = new Uint8Array(rawLength);

    for (var i = 0; i < rawLength; i++) {
        array[i] = raw.charCodeAt(i);
    }
    return array;
}

function numberWithCommas(x) {
    // convert 1234567 to '1,234,567'
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function round(number, precision) {
    // round  based on precision
    // 123.456 to 123.45 if precision is 2 or by default

    return number.toFixed(precision);
}
